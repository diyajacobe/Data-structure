#include<stdio.h>
#include<stdlib.h>
void push(int);
void pop();
void search(int);
void exit();
int ch=0,val,temp=0,sh;
struct node
{
int data;
struct node *next;
}*head=NULL;
void main()
{
do
{
printf("\n1.Insertion(push)\n 2> Deletion(pop) \n 3.Search \n 4.exit\n");
printf("enter your choice");
scanf("%d",&ch);
switch(ch)
{
case 1:
    printf("enter the value to insert");
    scanf("%d",&val);
    push(val);
    break;
case 2:
    pop(val);
    break;
case 3:
    printf("enter the element to search");
    scanf("%d",&sh);
    search(sh);
    break;
case 4:
    exit(0);
        break;
default:printf("\nEnter valid choice!!");
}
}
while(ch!=5);

}
void push(val)
{
    struct node *newNode=malloc(sizeof(struct node));
    newNode->data=val;
    if(head==NULL)
    {
        newNode->next=head;
        head=newNode;
    }
    else
    {
        newNode->next=head;
        head=newNode;
    }
        if(head==NULL)
   {
      printf("\n stack is Empty\n");
   }
   else
   {
      struct node *temp=head;
      printf("\nStack elements are - \n");
      while(temp->next!=NULL)
      {
     printf("%d --->",temp->data);
     temp=temp->next;
      }
printf("%d --->NULL",temp->data);
   }


}
void pop()
{
    struct node *temp;
    if(head==NULL)
    {
        printf("\n stack is empty no element to delete");
    }
    else
    {
        temp=head;
        if(temp!=NULL && temp->next==NULL)
        {

            temp=temp->next;
            free(temp);
        }
        else
        {
            head=temp->next;
            free(temp);
        }
    }
    if(head==NULL)
   {
      printf("\n stack is Empty\n");
   }
   else
   {
      struct node *temp=head;
      printf("\nStack elements are - \n");
      while(temp->next!=NULL)
      {
     printf("%d --->",temp->data);
     temp = temp->next;
      }
      printf("%d --->NULL",temp->data);
   }
}
void search(sh)
{
    struct node *newNode=malloc(sizeof(struct node));

    if(val==sh)
    {
        printf("%d is found in stack",sh);
    }
    else
    {
        printf("not found");
    }

}


